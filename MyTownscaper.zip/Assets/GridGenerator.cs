﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridGenerator : MonoBehaviour
{
    [SerializeField]
    private int radius;
    [SerializeField]
    private int height;
    [SerializeField]
    private float cellSize;
    [SerializeField]
    private float cellHeight;
    [SerializeField]
    private int relaxTimes;
    public Transform addSphere;
    public Transform deleteSphere;

    private Grid grid;
    private void Awake()
    {
        MonoBehaviour.print("Awake");
        
    }

    private void Start()
    {
        grid = new Grid(radius, height, cellSize, cellHeight, relaxTimes);
    }

    private void OnDrawGizmos() {
        if(grid != null){
            // foreach(Vertex_hex vertex in grid.hexes)
            // {
            //     Gizmos.DrawSphere(vertex.currentPosition, 0.1f);
            //     MonoBehaviour.print(vertex.currentPosition.ToString());
            // }
            // Gizmos.color = Color.yellow;
            // foreach(Triangle triangle in grid.triangles)
            // {
            //     Gizmos.DrawLine(triangle.a.currentPosition, triangle.b.currentPosition);
            //     Gizmos.DrawLine(triangle.a.currentPosition, triangle.c.currentPosition);
            //     Gizmos.DrawLine(triangle.b.currentPosition, triangle.c.currentPosition);

            //     Gizmos.DrawSphere((triangle.a.currentPosition + triangle.b.currentPosition + triangle.c.currentPosition) / 3, 0.05f);
            // }
            // Gizmos.color = Color.green;
            // foreach(Quad quad in grid.quads)
            // {
            //     Gizmos.DrawLine(quad.a.currentPosition, quad.b.currentPosition);
            //     Gizmos.DrawLine(quad.b.currentPosition, quad.c.currentPosition);
            //     Gizmos.DrawLine(quad.c.currentPosition, quad.d.currentPosition);
            //     Gizmos.DrawLine(quad.a.currentPosition, quad.d.currentPosition);
            // }
            // Gizmos.color = Color.red;
            // foreach(Vertex_mid mid in grid.mids)
            // {
            //     Gizmos.DrawSphere(mid.currentPosition, 0.2f);
            // }
            // Gizmos.color = Color.cyan;
            // foreach(Vertex_center center in grid.centers)
            // {
            //     Gizmos.DrawSphere(center.currentPosition, 0.2f);
            // }
            // Gizmos.color = Color.white;
            // foreach(SubQuad subQuad in grid.subQuads)
            // {
            //     Gizmos.DrawLine(subQuad.a.currentPosition, subQuad.b.currentPosition);
            //     Gizmos.DrawLine(subQuad.b.currentPosition, subQuad.c.currentPosition);
            //     Gizmos.DrawLine(subQuad.c.currentPosition, subQuad.d.currentPosition);
            //     Gizmos.DrawLine(subQuad.a.currentPosition, subQuad.d.currentPosition);
            // }
            Gizmos.color = Color.gray;
            foreach(Vertex_hex vertex in grid.hexes)
            {
                foreach(Vertex_Y vertex_Y in vertex.vertex_Ys)
                {
                    if(vertex_Y.isActive){
                        Gizmos.color = Color.red;
                        Gizmos.DrawSphere(vertex_Y.worldPosition,0.3f);
                    }
                    else{
                        Gizmos.color = Color.gray;
                        Gizmos.DrawSphere(vertex_Y.worldPosition,0.05f);
                    }
                        
                }
            }
        }
        
    }

    void Update(){
        if(grid != null){
            // Test
            // grid.Relax();
            foreach(Vertex vertex in grid.vertices)
            {
                foreach(Vertex_Y vertex_Y in vertex.vertex_Ys)
                {
                    if(!vertex_Y.isActive && Vector3.Distance(vertex_Y.worldPosition, addSphere.position) < 2f)
                    {
                        vertex_Y.isActive = true;
                    }else if(vertex_Y.isActive && Vector2.Distance(vertex_Y.worldPosition, deleteSphere.position) < 2f)
                    {
                        vertex_Y.isActive = false;
                    }
                }
            }
        }
    }
}
