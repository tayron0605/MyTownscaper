using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class Vertex
{
    public Vector3 initialPosition;
    public Vector3 currentPosition;
    public Vector3 offset = Vector3.zero;
    public List<Vertex_Y> vertex_Ys = new List<Vertex_Y>();
    public void Relex()
    {
        currentPosition = initialPosition + offset;
    }
}

public class Coord
{
    public readonly int q;
    public readonly int r;
    public readonly int s;

    public readonly Vector3 worldPosition;
    public Coord(int q, int r, int s)
    {
        this.q = q;
        this.r = r;
        this.s = s;
        worldPosition = WorldPosition();
    }

    public Vector3 WorldPosition()
    {
        return new Vector3(q * Mathf.Sqrt(3) / 2, 0, -(float)r - ((float)q/2)) * 2 * Grid.cellSize;
    }
    static public Coord[] directions = new Coord[]
    {
        new Coord(0,1,-1),
        new Coord(-1,1,0),
        new Coord(-1,0,1),
        new Coord(0,-1,1),
        new Coord(1,-1,0),
        new Coord(1,0,-1)
    };

    static public Coord Direction(int direction)
    {
        return Coord.directions[direction];
    }

    public Coord Add(Coord coord)
    {
        return new Coord(q + coord.q, r+ coord.r, s + coord.s);
    }

    public Coord Scale(int k)
    {
        return new Coord(q * k, r * k, s * k);
    }

    public Coord Neighbor(int direction)
    {
        return Add(Direction(direction));
    }

    public static List<Coord> Coord_Ring(int radius)
    {
        List<Coord> result = new List<Coord>();
        if (radius == 0)
        {
            result.Add(new Coord(0, 0, 0));
        }else{
            Coord coord = Coord.Direction(4).Scale(radius);
            for(int i = 0;i < 6;i++)
            {
                for(int j = 0;j < radius;j++)
                {
                    result.Add(coord);
                    coord = coord.Neighbor(i);
                }
            }
        }
        return result;
    }

    public static List<Coord> Coord_Hex(int radius)
    {
        List<Coord> result = new List<Coord>();
        for(int i = 0;i <= radius;i++)
        {
            result.AddRange(Coord_Ring(i));
        }
        return result;
    }
}

public class Vertex_hex: Vertex
{
    public readonly Coord coord;
    public Vertex_hex(Coord coord)
    {
        this.coord = coord;
        initialPosition = coord.worldPosition;
        currentPosition = initialPosition;
    }
    public static void Hex(List<Vertex_hex> vertices, int radius)
    {
        foreach (Coord coord in Coord.Coord_Hex(radius))
        {
            vertices.Add(new Vertex_hex(coord));
        }
    }

    public static List<Vertex_hex> GrabRing(int radius, List<Vertex_hex> vertices)
    {
        if(radius == 0)
            return vertices.GetRange(0,1);
        return vertices.GetRange(radius * (radius - 1) * 3 + 1, radius * 6);
    }
}

public class Vertex_mid : Vertex
{
    public Vertex_mid(Edge edge, List<Vertex_mid> mids)
    {
        Vertex_hex a = edge.hexes.ToArray()[0];
        Vertex_hex b = edge.hexes.ToArray()[1];
        mids.Add(this);
        initialPosition = (a.coord.worldPosition + b.coord.worldPosition) / 2;
        currentPosition = initialPosition;
    }
}

public class Vertex_center : Vertex {}
public class Vertex_triangleCenter : Vertex_center
{
    public Vertex_triangleCenter(Triangle triangle)
    {
        initialPosition = (triangle.a.coord.worldPosition + triangle.b.coord.worldPosition + triangle.c.coord.worldPosition) / 3;
        currentPosition = initialPosition;
    }
}

public class Vertex_quadCenter : Vertex_center
{
    public Vertex_quadCenter(Quad quad)
    {
        initialPosition = (quad.a.coord.worldPosition + quad.b.coord.worldPosition + quad.c.coord.worldPosition + quad.d.coord.worldPosition) / 4;
        currentPosition = initialPosition;
    }
}

public class Vertex_Y
{
    public readonly Vertex vertex;
    public readonly int y;
    public readonly Vector3 worldPosition;
    public bool isActive;
    public Vertex_Y(Vertex vertex, int y)
    {
        this.vertex = vertex;
        this.y = y;
        worldPosition = vertex.currentPosition + Vector3.up * (y * Grid.cellHeight);
    }
}